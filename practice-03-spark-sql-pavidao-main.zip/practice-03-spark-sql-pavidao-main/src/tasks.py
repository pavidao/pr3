"""
Цей модуль містить завдання Spark.
"""

from pyspark.sql import SparkSession, DataFrame
from typing import Literal, Optional


def full_function(free_slots: int) -> int:
    """
    Визначає, чи станція знаходиться в заповненому стані на основі кількості вільних слотів.
    
    Аргументи:
        free_slots: Кількість вільних слотів на станції
        
    Повертає:
        1, якщо станція заповнена (free_slots = 0), 0 в іншому випадку
    """
    if free_slots == 0:
        return 1
    else:
        return 0


def read_register_data(spark: SparkSession, input_path: str) -> DataFrame:
    """
    Зчитує файл register.csv у DataFrame.
    
    Аргументи:
        spark: SparkSession
        input_path: Шлях до файлу register.csv
        
    Повертає:
        DataFrame з даними реєстру
    """
    pass


def filter_corrupted_data(df: DataFrame) -> DataFrame:
    """
    Відфільтровує пошкоджені дані, де і free_slots, і used_slots дорівнюють 0.
    
    Аргументи:
        df: DataFrame з даними реєстру
        
    Повертає:
        DataFrame з видаленими пошкодженими даними
    """
    pass


def create_timeslot_status_df(df: DataFrame) -> DataFrame:
    """
    Створює DataFrame з полями: station, dayofweek, hour та fullstatus.
    
    Аргументи:
        df: DataFrame з очищеними даними реєстру
        
    Повертає:
        DataFrame з інформацією про часовий інтервал та статус
    """
    pass


def calculate_criticality(df: DataFrame) -> DataFrame:
    """
    Обчислює критичність для кожної групи (station, dayofweek, hour).
    Критичність визначається як середнє значення fullstatus.
    
    Аргументи:
        df: DataFrame з інформацією про часовий інтервал та статус
        
    Повертає:
        DataFrame з обчисленою критичністю для кожної групи
    """
    pass


def filter_by_threshold(df: DataFrame, threshold: float = 0.25) -> DataFrame:
    """
    Відфільтровує рядки, де критичність перевищує вказаний поріг.
    
    Аргументи:
        df: DataFrame з обчисленою критичністю
        threshold: Мінімальний поріг критичності (за замовчуванням: 0.25)
        
    Повертає:
        DataFrame лише з рядками, що перевищують поріг
    """
    pass


def read_stations_data(spark: SparkSession, input_path: str) -> DataFrame:
    """
    Зчитує файл stations.csv у DataFrame.
    
    Аргументи:
        spark: SparkSession
        input_path: Шлях до файлу stations.csv
        
    Повертає:
        DataFrame з даними станцій
    """
    pass


def join_with_stations(critical_df: DataFrame, stations_df: DataFrame) -> DataFrame:
    """
    Об'єднує критичні часові інтервали з таблицею станцій для отримання координат станцій.
    
    Аргументи:
        critical_df: DataFrame з критичними часовими інтервалами
        stations_df: DataFrame з даними станцій
        
    Повертає:
        Об'єднаний DataFrame з координатами станцій
    """
    pass


def sort_and_save_results(df: DataFrame, output_path: str) -> None:
    """
    Сортує результати та зберігає їх у CSV-файл.
    
    Порядок сортування:
    1. Критичність (за спаданням)
    2. ID станції (за зростанням)
    3. День тижня (за зростанням)
    4. Година (за зростанням)
    
    Аргументи:
        df: Об'єднаний DataFrame з критичними часовими інтервалами та інформацією про станції
        output_path: Шлях для збереження результатів
        
    Повертає:
        None
    """
    pass
